$OutDir  = Join-Path $env:USERPROFILE "AppData\Local\Steam_CheckerBootstrap"
$Report  = Join-Path $OutDir "bootstrap.log"
$LogEnc  = 'utf8'

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

function Write-Step($msg) { Write-Host "- $msg" }
function Write-Report($text) {
  $enc = if ($LogEnc -ieq 'utf8') { [System.Text.UTF8Encoding]::new($false) } else { [System.Text.Encoding]::GetEncoding($LogEnc) }
  for ($i=0; $i -lt 12; $i++) {
    try {
      $fs = [System.IO.File]::Open($Report, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::ReadWrite)
      $fs.Seek(0, [System.IO.SeekOrigin]::End) | Out-Null
      $sw = New-Object System.IO.StreamWriter($fs, $enc)
      $sw.WriteLine($text)
      $sw.Flush()
      $sw.Dispose()
      $fs.Dispose()
      break
    } catch {
      Start-Sleep -Milliseconds (100 * [Math]::Pow(2, [Math]::Min($i,6)))
      if ($i -eq 11) { Write-Host "log write failed: $($_.Exception.Message)" }
    }
  }
}

Write-Report ("Steam Checks - {0}`r`n" -f (Get-Date))
Write-Report "Output folder: $OutDir`r`n"

Write-Step "Reviewing Documents..."
Write-Report "RecentDocs (.dll/.zip/.rar)"

$recentBase = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs'
$targets = '.dll','.zip','.rar'
$encRecent = [System.Text.Encoding]::GetEncoding(0)

foreach ($ext in $targets) {
  $keyPath = Join-Path $recentBase $ext
  if (Test-Path $keyPath) {
    Write-Report "`r`n[$ext]"
    $values = (Get-Item $keyPath).GetValueNames() | Where-Object { $_ -ne 'MRUListEx' }
    foreach ($name in $values) {
      $raw = (Get-ItemProperty -Path $keyPath -Name $name).$name
      if ($raw -is [byte[]]) {
        $decoded = $encRecent.GetString($raw) -replace "`0",""
        if ($decoded) { Write-Report " - $decoded" }
      }
    }
  } else {
    Write-Report "`r`n[$ext] (no key)"
  }
}
Write-Step "Documents review complete."

Write-Step "Copying files..."
Write-Report "`r`nSteamVR settings"

function Try-CopySteamVR {
  param([string]$steamRoot)
  $cand = @(
    (Join-Path $steamRoot 'config\steamvr.vrsettings'),
    (Join-Path $steamRoot 'steamapps\common\SteamVR\resources\settings\steamvr.vrsettings'),
    (Join-Path $steamRoot 'steamapps\common\SteamVR\drivers\null\resources\settings\default.vrsettings')
  )
  foreach ($p in $cand) {
    if (Test-Path $p) {
      $dest = Join-Path $OutDir ([IO.Path]::GetFileName($p))
      Copy-Item $p $dest -Force
      Write-Report "Copied: $p -> $dest"
      return $true
    }
  }
  return $false
}

$steamPath = $null
try { $steamPath = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch {}

$copied = $false
if ($steamPath) { $copied = Try-CopySteamVR -steamRoot $steamPath }
if (-not $copied) {
  $commonGuesses = @("$env:ProgramFiles(x86)\Steam","$env:ProgramFiles\Steam","$env:ProgramData\Steam")
  foreach ($g in $commonGuesses) {
    if (Test-Path $g -PathType Container) {
      if (Try-CopySteamVR -steamRoot $g) { $copied = $true; break }
    }
  }
}
if (-not $copied) { Write-Report "steamvr.vrsettings not found." }
Write-Step "Copy complete."

Write-Step "Scanning drives... (This may take awhile)"
Write-Report "`r`nBepInEx plugins"

$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -ne $null }
$suspectRoots = @()
foreach ($d in $drives) {
  try {
    $found = Get-ChildItem -Path ($d.Root) -Directory -Recurse -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -match 'Gorilla Tag\\BepInEx\\plugins$' }
    if ($found) { $suspectRoots += $found }
  } catch {}
}

if ($suspectRoots.Count -eq 0) {
  Write-Report "No plugins folders found."
} else {
  foreach ($root in $suspectRoots) {
    Write-Report "`r`n[Plugins folder] $($root.FullName)"
    $dlls = Get-ChildItem -Path $root.FullName -Filter *.dll -File -ErrorAction SilentlyContinue
    if ($dlls.Count -eq 0) {
      Write-Report " (empty)"
    } else {
      foreach ($f in $dlls) {
        try {
          $hash = (Get-FileHash -Algorithm SHA256 -Path $f.FullName).Hash
          $line = ("{0} | {1} bytes | {2} | SHA256 {3}" -f $f.Name, ($f.Length), ($f.LastWriteTime.ToString("yyyy-MM-dd HH:mm")), $hash)
          Write-Report " - $line"
        } catch {
          Write-Report " - $($f.Name) | hash error: $($_.Exception.Message)"
        }
      }
    }
  }
}
Write-Step "Drive scan complete."

Write-Report "`r`nCompleted at $(Get-Date)"
Write-Step "Finalizing..."

$ZipPath = Join-Path $OutDir "bundle.zip"
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }
Compress-Archive -Path (Join-Path $OutDir '*') -DestinationPath $ZipPath -Force -ErrorAction SilentlyContinue
Write-Step "Packaging complete."

$cfgCandidates = @(
  (Join-Path $PSScriptRoot 'smtp_config.json'),
  (Join-Path $OutDir 'smtp_config.json')
)
$cfgPath = $cfgCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $cfgPath) {
  Write-Step "Email skipped (smtp_config.json missing)."
} else {
  try {
    $cfg = Get-Content -Path $cfgPath -Raw | ConvertFrom-Json
    $client = New-Object System.Net.Mail.SmtpClient($cfg.SmtpHost, [int]$cfg.SmtpPort)
    $client.EnableSsl = [bool]$cfg.UseSsl
    $client.Credentials = New-Object System.Net.NetworkCredential($cfg.Username, $cfg.AppPassword)
    $mail = New-Object System.Net.Mail.MailMessage($cfg.From, $cfg.To)
    $mail.Subject = ("{0} Steam Checker {1}" -f $cfg.SubjectPrefix, (Get-Date -Format 'yyyy-MM-dd HH:mm'))
    $mail.Body = "Attached: report and bundle."
    if (Test-Path $Report) { $mail.Attachments.Add($Report) | Out-Null }
    if (Test-Path $ZipPath) { $mail.Attachments.Add($ZipPath) | Out-Null }
    $client.Send($mail)
    $mail.Dispose()
    Write-Step "Email sent."
  } catch {
    Write-Step "Email failed."
  }
}

Write-Step "Checks finished successfully."